import { Module } from '@nestjs/common';

@Module({
  providers: [],
})
export class SharedModule {}

export enum Status {
  ACTIVO = 'ACTIVO',
  INACTIVO = 'INACTIVO',
}

export enum RoleType {
  ADMIN = 'ADMIN',
  GENERAL = 'GENERAL',
}

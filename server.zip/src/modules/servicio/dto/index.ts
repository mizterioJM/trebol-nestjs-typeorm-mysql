export { CreateServicioDto } from './create-servicio.dto';
export { ReadServicioDto } from './read-servicio.dto';
export { UpdateServicioDto } from './update-servicio.dto';
export { CreateServicioImgDto } from './create-service-img-detail.dto';
